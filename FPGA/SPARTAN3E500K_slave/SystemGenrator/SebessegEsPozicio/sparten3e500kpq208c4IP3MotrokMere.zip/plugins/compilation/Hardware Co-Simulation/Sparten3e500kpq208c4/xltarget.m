%
% Filename:    xltarget.m 
%
% Description: Defines the target compilation entry point for the
%              Sparten3e500kpq208c4

function s = xltarget
  s.('name') = 'Sparten3e500kpq208c4';
  s.('target_info') = 'sparten3e500kpq208c4ip3motrokmere_target';
  s.('libgen_info') = 'sparten3e500kpq208c4ip3motrokmere_libgen';
  s.('sbd_xml') = 'sparten3e500kpq208c4ip3motrokmere.xml';
