%
% Filename:    xltarget.m 
%
% Description: Defines the target compilation entry point for the
%              sPARTANlAP

function s = xltarget
  s.('name') = 'sPARTANlAP';
  s.('target_info') = 'sparten3e500kpq208c4_target';
  s.('libgen_info') = 'sparten3e500kpq208c4_libgen';
  s.('sbd_xml') = 'sparten3e500kpq208c4.xml';
